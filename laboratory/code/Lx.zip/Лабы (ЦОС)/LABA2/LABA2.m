%2.2.1
k = 0.09316;
z = [-0.99868+0.05141i,-0.99868-0.05141i];
p = [0.51743+0.40197i,0.51743-0.40197i];
[a,b] = to_ab_transform(z,p,k);
%2.2.2
x = 0:20;
in_signal = delta(x);
out_signal_1 = filter(b,a,in_signal);
out_signal_2 = my_filter(b,a,in_signal);

f1 = figure;
subplot(211);
stem(x,out_signal_1);
title('filter function');
subplot(212);
stem(x,out_signal_2);
title('my filter function');

%2.2.3
A = [1 1; p(1) p(2)];
b1 = out_signal_1(1:2).';
alpha_beta = (A\b1).';

n = 0:20;
h = ((alpha_beta(1)*(p(1).^n)+alpha_beta(2)*(p(2).^n)).*unit_step(n));
f2 = figure;
stem(n,h);
title('h(n)');

%2.2.4
x = 0:1:20;
in_signal = unit_step(x-1);
response = my_filter(b,a,in_signal);

f3 = figure;
stem(x,response);

%2.2.5
f4 = figure;

f = 10;
fs = 80;

t = 0:1/fs:1;
in_signal = sq_sig(2*pi*f*t);

subplot(311);
stem(t,in_signal);
ylim([-2 2]);

subplot(312);
response_sq = my_filter(b,a,in_signal);
stem(t,response_sq);

f = 20;
fs = 80;
t = 0:1/fs:1;
in_signal = sq_sig(2*pi*f*t);

subplot(313);
response_sq = my_filter(b,a,in_signal);
stem(t,response_sq);

%2.2.6
w = 0:0.001:pi;
b_t = b.';
a_t = a.';
exx = [exp(i*w*0).' exp(i*w*1).' exp(i*w*2).'];
ex = exp(i*w);
H = (b*exx.')./(a*exx.');

f5 = figure;
subplot(211);
plot(w,abs(H));
subplot(212);
plot(w,arg(H));

%2.2.7
[hh,ww] = freqz (b,a,w);
f6 = figure;
subplot(211);
plot(ww,(abs(hh)));
subplot(212);
plot (ww,arg(hh));


##%2.2.8
##Fs = 48000;
##F0 = 440*[2^-(31/12); 2^-(19/12); 2^-(16/12); 2^(-14/12); 2^-(4/12); 1; 2^(3/12); 2^(10/12)];
##gain = [1.2 3.0 1.0 2.2 1.0 1.0 1.0 3.5];
##duration = 4;
##alpha = 0.9785;
##nbsample_chord = Fs*duration;
##first_duration = ceil(nbsample_chord / round(Fs/F0(1)));
##chord = zeros(nbsample_chord, 1);
##for i = 1:length(F0)
##  current_M = round(Fs/F0(i));
##  current_duration = ceil(nbsample_chord/current_M);
##  current_alpha = alpha^(first_duration/current_duration);
##  x = (1/3)*rand(current_M, 1);
##  y = ks_synthesis (x, current_alpha, current_duration);
##  y = y(1:nbsample_chord);
##  chord = chord + gain(i) * y;
##end
##sound(chord,nbsample_chord);