%------------������� 1------------
k = 0.44405;
z1 = -0.99992 + 0.01297*1j;
z2 = -0.99992 - 0.01297*1j;
p1 = -0.28370 + 0.48321*1j;
p2 = -0.28370 - 0.48321*1j;
b = k.*[1 -(z1+z2) z1*z2]; %b[i]
a = [1 -(p1+p2) p1*p2]; %a[i]
%------------������� 2------------
n = 35;
x = [1, zeros(1, n-1)];
X1 = x;
X2 = filter(b,a,x);
X3 = raz_filter(b, a, x);
figure('Name','Zadanie 2','NumberTitle','off');
subplot(131);
stem(X1);
subplot(132);
stem (X2);
subplot(133);
stem (X3);

%------------������� 3------------

n2 = 0:35;
A = [1 1;p1 p2];
B = [0.4441;0.6361];
C = A\B;
res = (C(1)* p1.^n2 + C(2) * p2.^n2).*unit_step(n2);
figure('Name','Zadanie 3','NumberTitle','off');
stem(res);

%------------������� 4------------
n0=2;
N = 22 - n0
unitx = unit_step(-5:N);
figure('Name','Zadanie 4','NumberTitle','off');
subplot(121);
stem(-5:N,unitx);
unitxf = raz_filter(b, a, unitx);
subplot(122);
stem(-5:N,unitxf);
otklik = unitxf(25)

%------------������� 5------------
f1 = 10;
f2 = 20;
fs = 80;
rect_sig1 = square_sig(f1, fs, 0, 1);
figure('Name','Zadanie 5','NumberTitle','off');
subplot(221);
stem(1:81,rect_sig1);
rect_sig2 = square_sig(f2, fs, 0, 1);
subplot(222);
stem(1:81,rect_sig2);
rect_sig1f = raz_filter(b, a, rect_sig1);
subplot(223);
stem(1:81,rect_sig1f);
rect_sig2f = raz_filter(b, a, rect_sig2);
subplot(224);
stem(1:81,rect_sig2f);
%------------������� 5 right version------------
f1 = 1;
f2 = 2;
fs = 8000;
rect_sig1 = square_sig(f1, fs, 0, 1);
figure('Name','Zadanie 5 right version','NumberTitle','off');
subplot(221);
plot(rect_sig1);
rect_sig2 = square_sig(f2, fs, 0, 1);
subplot(222);
plot(rect_sig2);
rect_sig1f = raz_filter(b, a, rect_sig1);
subplot(223);
plot(rect_sig1f);
rect_sig2f = raz_filter(b, a, rect_sig2);
subplot(224);
plot(rect_sig2f);
%------------������� 6------------

[a4h, f4h] = zadanie_6(0:pi/180:pi,b,a);
figure('Name','Zadanie 6','NumberTitle','off');
subplot(121);
plot(a4h);
subplot(122);
plot(f4h);



% function y = myfun(b, a, x)
% y = zeros(1,length(x));
% for i=4:length(x)
%     sum1 = 0;
%     sum2 = 0;
%     for j=1:3
%         sum1 = sum1 + (b(4-j)*x(i-j));
%         if j == 1
%             continue;
%         end
%         sum2 = sum2 + (a(4-(j-1))*y(i-(j-1)));
%     end
%     y(i) = sum1 - sum2;
% end
% end

function [ y0 ] = raz_filter( B, A, x )

    for j=1:length(x)
        
        ay=0; 
        bx=0;
        
        for i = 1:length(B)
            if (j-i+1)>=1
                bx = bx+B(i)*x(j-i+1);
            end
        end
        
        for i = 2:length(A)
            if (j-i+1)>=1
                ay=ay+A(i)*y0(j-i+1);     
            end 
        end
        
        y0(j)=bx-ay;
        
    end
    
end

function y = delta(n)
y = (n == 0);      
end

function y = unit_step(n)
y(n >= 0) = 1;      
end

function [x, t_mark] = square_sig(f, Fs, t0, t1)
t_mark = t0:1/Fs:t1;
Ln = length(t_mark);
x = zeros(1,Ln);
for n=1:Ln
    x(n) = sq_sig(t_mark(n),1/f);
end
end


function y = sq_sig(time, period)

while time>period
    time = time - period; 
end

if time>period/2.0
    y = 1;
else
    y = -1;
end

end

function [module, argument] = zadanie_6(w,b,a)
for i = 1:length(w)
    nominator = 0;
    denominator = 1;
    for j=1:3
        nominator = nominator + b(j) * exp(1j*w(i)*j);
        if j > 1
            denominator = denominator + a(j) * exp(1j * w(i) * j);
        end
    end
    H = nominator/denominator;
    module(i) = abs(H);
    argument(i) = angle(H);
end
end
