function [z, p, k] = tf2zp(b, a)
  if nargin!=2 || nargout!=3,
    usage("[z, p, k] = tf2zp(b, a)");
  endif
  if isempty(b) || isempty(a)
    error("tf2zp b or a is empty. Perhaps already in zero-pole form?");
  endif
  k = b(1)/a(1);
  z = roots(b);
  p = roots(a);
endfunction
function y = delta(x)
  y = (x==0);
end
function y = unit_step(x)
  y(x>0) = 1;
end
function [out] = my_filter(b,a,in)
    for j=1:length(in)
        sum_a=0;
        sum_b=0;
        for i = 1:length(b); 
            if (j-i+1)<1
                sum_b = sum_b+b(i)*0;
            else
                sum_b = sum_b+b(i)*in(j-i+1);
            end
            if(i+1<=length(b))
              if (j-(i+1)+1)<1
                  sum_a=sum_a+a(i+1)*0;
              else
                  sum_a=sum_a+a(i+1)*out(j-(i+1)+1);     
            end 
            end
        end
     out(j)=sum_b-sum_a;   
    end
end
function s = trapezoid(t)
tmp = mod(t-pi/4,2*pi);


tmp = mod(t+pi/4,2*pi);

a = (tmp < pi/2);
b = (tmp >= pi/2 & tmp < pi);
c = (tmp >= pi & tmp < 3*pi/2);

rise = 2*tmp/pi;
fall = -2*(tmp-pi)/pi+1;

nodd = a.*rise + b + c.*fall;

s = 2*nodd-1;
endfunction