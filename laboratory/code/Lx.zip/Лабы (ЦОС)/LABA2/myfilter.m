function [output] = my_filter_haha( b, a, x )
    for j=1:length(x)
        sum_ay=0;
        sum_bx=0;
        k=2;
        for i = 1:length(b); 
            if (j-i+1)>=1
                sum_bx = sum_bx+b(i)*x(j-i+1);
            end
            if (j-k+1)>=1
                sum_ay=sum_ay+a(k)*output(j-k+1);     
            end
            if k<length(b)
              k = k+1;
            end
        end
     output(j)=sum_bx-sum_ay;   
    end
end

