t = 0:1/520:1
f1 = 18
f2 = 130
out1 = trapezoid(2*pi*f1*t)
out2 = trapezoid(2*pi*f2*t)

fig = figure;
subplot(211)
stem(t,out1)
subplot(212)
stem(t,out2)