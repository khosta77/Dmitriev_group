function [a,b] = to_ab_transform(z, p, k)
  a = poly(p);
  b = k * poly(z);
endfunction
function y = delta(x)
  y = (x==0);
end
function y = unit_step(x)
  y(x>0) = 1;
end
function out = my_filter1(b, a, in) %����������� ������� filter
    step_len = length(a);
    
    in = [zeros(size(a)), in];
    a_1 = a(1);
    a = flip(a(2:end)).';
    b = flip(b).';
    
    out = zeros(size(in));
    for idx = step_len+1:length(in)
        weight_b = in(idx-step_len+1:idx) * b;
        weight_a = out(idx-step_len+1:idx-1) * a;
        
        out(idx) = weight_b - weight_a;
    end
    
    out = out / a_1;
    out = out(step_len+1:end);
end
function s = sq_sig(t,duty)
if nargin < 2
	duty = 50;
end
% Compute values of t normalized to (0,2*pi)
tmp = mod(t,2*pi);

% Compute normalized frequency for breaking up the interval (0,2*pi)
w0 = 2*pi*duty/100;

% Assign 1 values to normalized t between (0,w0), 0 elsewhere
nodd = (tmp < w0);

% The actual square wave computation
s = 2*nodd-1;
endfunction
function [out] = my_filter(b,a,in)
    for j=1:length(in)
        sum_weight_a=0;
        sum_weight_b=0;
        for i = 1:length(b); 
            if (j-i+1)<1
                sum_weight_b = sum_weight_b+b(i)*0;
            else
                sum_weight_b = sum_weight_b+b(i)*in(j-i+1);
            end
            if(i+1<=length(b))
              if (j-(i+1)+1)<1
                  sum_weight_a=sum_weight_a+a(i+1)*0;
              else
                  sum_weight_a=sum_weight_a+a(i+1)*out(j-(i+1)+1);     
            end 
            end
        end
     out(j)=sum_weight_b-sum_weight_a;   
    end
end
function y = ks_synthesis(in,alpha,P)
  M = length(in);
  y = [in; zeros((P-1)*M, 1)];
  for i = M+1:length(y)
    y(i) = alpha*y(i-M)+y(i);
  endfor
  endfunction
