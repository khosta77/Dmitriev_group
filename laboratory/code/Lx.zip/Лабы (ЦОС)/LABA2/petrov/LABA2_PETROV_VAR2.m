%2.2.1
k = 0.44405;
z = [-0.99992+0.01297i,-0.99992-0.01297i];
p = [-0.28370+0.48321i,-0.28370-0.48321i];
[a,b] = to_ab_transform(z,p,k);
%2.2.2
x = 0:20;
in_signal = delta(x);
out_signal_1 = filter(b,a,in_signal);
out_signal_2 = my_filter(b,a,in_signal);

f1 = figure;
subplot(211);
stem(x,out_signal_1);
title('������');
subplot(212);
stem(x,out_signal_2);
title('���������� ������');

%2.2.3

A = [1 1; p(1) p(2)];
b1 = out_signal_1(1:2).';
alpha_beta = (A\b1).';

n = 0:20;
h = ((alpha_beta(1)*(p(1).^n)+alpha_beta(2)*(p(2).^n)).*unit_step(n));
f2 = figure;
stem(n,h);
title('h(n) / alpha-beta');
%2.2.4
x = 0:1:20;
in_signal = unit_step(x-2);
response = filter(b,a,in_signal);

f3 = figure;
stem(x,response);

%2.2.5
f4 = figure;

f = 10;
fs = 80;

t = 0:1/fs:1;
in_signal = sq_sig(2*pi*f*t);

subplot(311);
stem(t,in_signal);
ylim([-2 2]);

subplot(312);
response_sq = my_filter(b,a,in_signal);
stem(t,response_sq);

f = 20;
fs = 80;
t = 0:1/fs:1;
in_signal = sq_sig(2*pi*f*t);

subplot(313);
response_sq = my_filter(b,a,in_signal);
stem(t,response_sq);

%2.2.6
w = 0:0.001:pi;
b_t = b.';
a_t = a.';
exx = [exp(i*w*0).' exp(i*w*1).' exp(i*w*2).'];
ex = exp(i*w);
H = (b*exx.')./(a*exx.');

f5 = figure;
subplot(211);
plot(w,abs(H));
subplot(212);
plot(w,arg(H));

%2.2.7
[hh,ww] = freqz (b,a,w);
f6 = figure;
subplot(211);
plot(ww,(abs(hh)));
subplot(212);
plot (ww,arg(hh));

