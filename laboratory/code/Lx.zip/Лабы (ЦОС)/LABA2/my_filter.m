function [ y0 ] = my_filter( A, B, x )
     n=length(x);
    M=length(B);
    N=length(A);

    for j=1:n
        ay=0; bx=0;
        for i = 1:M; 
            if (j-i+1)<1
                bx = bx+B(i)*0;
            else
                bx = bx+B(i)*x(j-i+1);
            end
        end
        
        for i = 2:N;
            if (j-i+1)<1
                ay=ay+A(i)*0;
            else
                ay=ay+A(i)*y0(j-i+1);     
            end 
        end
     y0(j)=bx-ay;   
    end
end

