%2.2.1
a = [1 0.09241 1.63060];
b = [0.70587 0.07190 1.41295];
[z,p,k] = tf2zp(b,a);
%2.2.2
x = 0:20;
in_signal = delta(x);
out_signal_1 = filter(b,a,in_signal); %���������� ������
out_signal_2 = my_filter(b,a,in_signal); %���������� ������

f1 = figure;
subplot(211);
stem(x,out_signal_1);
title('filter');
subplot(212);
stem(x,out_signal_2);
title('my filter');

%2.2.3
A = [1 1; p(1) p(2)];
b1 = out_signal_1(1:2).';
alpha_beta = (A\b1).';

n = 0:20;
h = ((alpha_beta(1)*(p(1).^n)+alpha_beta(2)*(p(2).^n)).*unit_step(n));
f2 = figure;
stem(n,h);
title('h(n) / alpha-beta');

%2.2.4
x = 0:1:20;
in_signal = unit_step(x-6);
response = my_filter(b,a,in_signal);

f3 = figure;
stem(x,response);

%2.2.5
f4 = figure;

fs = 520;

t = 0:1/520:0.5;
f1 = 18;
f2 = 100;
out1 = abs(trapezoid(2*pi*f1*t));
out2 = abs(trapezoid(2*pi*f2*t));

subplot(311);
stem(t,out1);


subplot(312);
response_sq = my_filter(b,a,out1);
stem(t,response_sq);

subplot(313);
response_sq = my_filter(b,a,out2);
stem(t,response_sq);

%2.2.6
w = 0:0.001:pi;
b_t = b.';
a_t = a.';
exx = [exp(i*w*0).' exp(i*w*1).' exp(i*w*2).'];
ex = exp(i*w);
H = (b*exx.')./(a*exx.');

f5 = figure;
subplot(211);
plot(w,abs(H));
subplot(212);
plot(w,arg(H));

%2.2.7
[hh,ww] = freqz (b,a,w);
f6 = figure;
subplot(211);
plot(ww,(abs(hh)));
subplot(212);
plot (ww,arg(hh));