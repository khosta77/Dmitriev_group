function [P, P_db] = calc_power(in)
  P = sum(in.^2)/length(in);
  P_db = 10*log10(P);
endfunction
function Pxx = my_periodogram(in)
  Pxx = ((abs(fft(in))).^2)/length(fft(in));
endfunction
function out = r(in)
  out = rand(1, length(in));
endfunction
function out = SNR(P1,P2)
  out = 10*log10(P1/P2);
endfunction
function out = SPM(in)
  Npt   = length(in);
  Nsamp = 40;
  Nshift= 10;
  K = floor((Npt-Nsamp)/Nshift)+1;
  for i=1:K    
    x_i = in(1+(i-1)*Nshift:Nsamp+(i-1)*Nshift);
    out(i) = (1/K)*sum(my_periodogram(x_i));
  endfor
endfunction
function [x_v, x_u] = vu_separate(in, N, threshold)
  
endfunction
function [Pkr] = kratk_P(in)
  unnormalized  = zeros(1,length(in))
  for i = 1:length(in)
    unnormalized(i) = 0
    summa = 0
    for j = i - length(in)/2 : i + length(in)/2
      if (i - length(in)/2 < 1)
        value = 0
      elseif (i + length(in)/2 > length(in))
        value = 0
      else
        value = in(j)^2
      endif
      summma += value(i)
     endfor
     unnormalized(i) = summa/length(in)
  endfor
endfunction
function out = phi(in)
  N = length(in);
  out = zeros(1,N);
  for m = 1:N
    summa = 0;
    for i = 1:N
      if i+m > N
        summa += 0;
      else
        summa += in(i)*in(i+m);
      endif
    endfor
   out(m) = summa/N;
  endfor
endfunction
