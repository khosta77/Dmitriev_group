%4.2.1
n = 0:127;

x1 = 0.5*sin(2*pi*(3/128)*n);
x2 = 0.5*sin(2*pi*(30/128)*n);
x3 = 0.3*cos(2*pi*(6/128)*n) + 0.4*cos(2*pi*(10/128)*n);

[P1,P_db1] = calc_power(x1)
[P2,P_db2] = calc_power(x2)
[P3,P_db3] = calc_power(x3)

%4.2.2
Pxx1 = my_periodogram(x1);
Pxx2 = my_periodogram(x2);
Pxx3 = my_periodogram(x3);

fig1 = figure;
hold on;
subplot(211);
plot(n,x1);
title('x1 signal');
xlim([0 length(n)-1]);
subplot(212);
plot(n,Pxx1);
title('x1 periodogram');
xlim([0 length(n)-1]);

fig2 = figure;
subplot(211);
plot(n,x2);
title('x2 signal');
xlim([0 length(n)-1]);
subplot(212);
plot(n,Pxx2);
title('x2 periodogram');
xlim([0 length(n)-1]);

fig3 = figure;
subplot(211);
plot(n,x3);
xlim([0 length(n)-1]);
title('x3 signal');
subplot(212);
plot(n,Pxx3);
title('x3 periodogram');
xlim([0 length(n)-1]);

P_avg1 = (1/(length(n))^2)*sum(Pxx1 * length(n))
P_avg2 = (1/(length(n))^2)*sum(Pxx2 * length(n))
P_avg3 = (1/(length(n))^2)*sum(Pxx3 * length(n))

%4.2.3
n = 0:511;
A = 0.297;
x1 = 0.4*cos(2*pi*(9/128)*n);
x2 = A*r(n);
x = x1 + x2;

fig4 = figure;
stem(n,my_periodogram(x));
title('periodogram');

[P1,P_db1] = calc_power(x1);
[P2,P_db2] = calc_power(x2);

otn = SNR(P1,P2);


%4.2.4
n = 0:4095;
b = [0.00482434 0 -0.0192973 0 0.02894606 0 -0.0192973 0 0.00482434];
a = [1 -2.06958023 3.99771255 -4.3894077 4.45285533 -2.9060422 1.75168470 -0.5862147 0.18737949];
in = r(n);

%  Nsamp = 40;
%  Nshift= 10;

out = SPM(filter(b,a,in));

n = 0:length(out)-1;
fig5 = figure;
plot(n,out);
xlim([0 length(out)]);

%DOP
[y,fs] = audioread('female_high_11.wav');
y = y';
in = y(1:97280);
out = AKF(in);