%4.2.1
n = 0:127;

signal1 = 0.5*sin(2*pi*n*(3/128));
signal2 = 0.5*sin(2*pi*n*(30/128));
signal3 = 0.3*cos(2*pi*n*(6/128)) + 0.4*cos(2*pi*n*(10/128));

[P1,P_decibel_1] = power(signal1)
[P2,P_decibel_2] = power(signal2)
[P3,P_decibel_3] = power(signal3)

%4.2.2
Pxx_1 = my_periodogramma(signal1);
Pxx_2 = my_periodogramma(signal2);
Pxx_3 = my_periodogramma(signal3);

fig1 = figure;
hold on;
subplot(211);
plot(n,signal1);
title('sin1');
xlim([0 length(n)-1]);
subplot(212);
stem(n,Pxx_1);
title('sin1 periodogram');
xlim([0 length(n)-1]);

fig2 = figure;
subplot(211);
plot(n,signal2);
title('sin2');
xlim([0 length(n)-1]);
subplot(212);
stem(n,Pxx_2);
title('sin2 periodogram');
xlim([0 length(n)-1]);

fig3 = figure;
subplot(211);
plot(n,signal3);
xlim([0 length(n)-1]);
title('cos');
subplot(212);
stem(n,Pxx_3);
title('cos periodogram');
xlim([0 length(n)-1]);

P_sr1 = (1/(length(n))^2)*sum(Pxx_1 * length(n))
P_sr2 = (1/(length(n))^2)*sum(Pxx_2 * length(n))
P_sr3 = (1/(length(n))^2)*sum(Pxx_3 * length(n))

%4.2.3
n = 0:511;
A = 0.295;
x1 = 0.4*cos(2*pi*(9/128)*n);
x2 = A*r(n);
x = x1 + x2;

fig4 = figure;
stem(n,my_periodogramma(x));
title('signal + noise periodogram');

[P1,P_decibel_1] = power(x1);
[P2,P_decibel_2] = power(x2);

snr = SNR(P1,P2)


%4.2.4
n = 0:4095;
b = [0.00482434 0 -0.0192973 0 0.02894606 0 -0.0192973 0 0.00482434];
a = [1 -2.06958023 3.99771255 -4.3894077 4.45285533 -2.9060422 1.75168470 -0.5862147 0.18737949];
in = r(n);

%  Nsamp = 60;
%  Nshift= 20;

out = SPM(filter(b,a,in));

n = 0:length(out)-1;
fig5 = figure;
plot(n,out);
xlim([0 length(out)]);

%DOP
[y,fs] = audioread('female_high_11.wav');
y = y';
in = y(1:97280);
out = AKF(in);