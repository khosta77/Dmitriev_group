function [re, im] = dft_funcs(in)
  N = length(in);
  N2 = N / 2;
  k = 0:N2;
  n = 0:(N-1);

  out=(exp(-1i*2*pi*k'*n/N)*in')';
  
  re = real( out );
  im = -imag( out );
end
function [re, im] = my_dft(signal)
  len = length(signal);
  for k = 0:(length(signal)/2)
    s = 0;
    for n = 1:(length(signal))
      s += exp(-i*2*pi*k*n/len)*signal(n);
    endfor
    out(k+1) = s;
  endfor
  re = -real(out);
  im = imag(out);
endfunction
function [s, c] = SinCos(in)
  k = 0:(length(in)/2);
  n = 0:(length(in)-1);
  c = cos(2*pi*k'*n/length(in));
  s = sin(2*pi*k'*n/length(in));
endfunction
function [cA, sA] = SinCosAmps_reim(re,im)
  sA = -im/(length(im)-1);
  cA = re/(length(im)-1);
  cA(1) = cA(1)/(2*(length(im)-1));
  cA(128) = cA(128)/(2*(length(im)-1));
endfunction
function [M_k, Phi_k] = koef(sA,cA)
  M_k = sqrt(cA.^2+sA.^2);
  Phi_k = atan2(sA,cA);
endfunction
function out = obr_dft(M_k,Phi_k)
  k = 0:length(M_k)-1;
  n = 0:2*length(M_k)-3;
  out = M_k*cos(2*pi*k'*n/length(n)+Phi_k');
endfunction
function out = obratn_dft_amp(sA,cA)
  k = 0:(length(sA)-1);
  n = 0:(length(sA)*2-2);
  c = cos(2*pi*k'*n/(length(n)-1));
  s = sin(2*pi*k'*n/(length(n)-1));
  out = cA*c + sA*s;
endfunction
