function [a,b] = ab_trans(z, p, k)
  a = poly(p);
  b = k * poly(z);
endfunction
function y = delta(x)
  y = (x==0);
end
function y = unit_step(x)
  y(x>0) = 1;
end
function s = sq_sig(t,duty)
if nargin < 2
	duty = 50;
end
tmp = mod(t,2*pi);
w0 = 2*pi*duty/100;
nodd = (tmp < w0);
s = 2*nodd-1;
endfunction
function [out] = my_filter(b,a,in)
    for j=1:length(in)
        sum_a=0;
        sum_b=0;
        for i = 1:length(b); 
            if (j-i+1)<1
                sum_b = sum_b+b(i)*0;
            else
                sum_b = sum_b+b(i)*in(j-i+1);
            end
            if(i+1<=length(b))
              if (j-(i+1)+1)<1
                  sum_a=sum_a+a(i+1)*0;
              else
                  sum_a=sum_a+a(i+1)*out(j-(i+1)+1);     
            end 
            end
        end
     out(j)=sum_b-sum_a;   
    end
end
function s = trapezoid(t)
tmp = mod(t-pi/4,2*pi);


tmp = mod(t+pi/4,2*pi);

a = (tmp < pi/2);
b = (tmp >= pi/2 & tmp < pi);
c = (tmp >= pi & tmp < 3*pi/2);

rise = 2*tmp/pi;
fall = -2*(tmp-pi)/pi+1;

nodd = a.*rise + b + c.*fall;

s = 2*nodd-1;
endfunction