clc;
clear;
close all;

f = 32;
fs = 512;
A = 1;
t = 0:1/fs:1;
in = A*sin(2*pi*f*t);

[re, im] = dft_funcs(in);
ex = fft(in);
ex = ex( 1:end/2 );

fig1 = figure;
subplot(211);
plot(re);
title('My DFT VECTOR / Real');
subplot(212);
plot(im);
title('My DFT VECTOR / Imag');


fig2 = figure;
subplot(211);
plot(real(ex));
title('FFT / Real');
subplot(212);
plot(imag(ex));
title('FFT / Imag');