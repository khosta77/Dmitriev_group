function out = my_dft_for(in)
  N = length(in);
  for k = 1:(length(in)/2)
    sum = 0;
    for n = 1:(length(in))
      sum = sum + exp(-i*2*pi*(k-1)*n/N)*in(n);
    endfor
    out(k) = sum;
  endfor
endfunction