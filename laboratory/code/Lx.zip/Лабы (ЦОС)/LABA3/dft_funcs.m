function [re, im] = dft_funcs(in)
  N = length(in);
  N2 = N / 2;
  k = 0:N2;
  n = 0:(N-1);

  out=(exp(-1i*2*pi*k'*n/N)*in')';
  
  re = real( out );
  im = imag( out );
endfunction
##function out = my_dft(in)
##  k = 0:(length(in)/2);
##  n = 0:(length(in)-1);
##  N = length(in);
##  out=(exp(-i*2*pi*k'*n/N)*in')';
##endfunction
##function out = my_dft_for(in)
##  N = length(in);
##  for k = 0:(length(in)/2)
##    sum = 0;
##    for n = 1:(length(in))
##      sum = sum + exp(-i*2*pi*k*n/N)*in(n);
##    endfor
##    out(k+1) = sum;
##  endfor
##endfunction
##function X = dtf_dft(x)
##N = length(x);
##reX = zeros(1, N/2 + 1);
##imX = zeros(1, N/2 + 1);
##X = zeros(1, N);
##for k = 1:N/2
##  for n = 1:N
##    reX(k) = reX(k) + x(n)*cos(2*pi*(k-1)*(n-1)/N);
##    imX(k) = imX(k) -x(n)*sin(2*pi*(k-1)*(n-1)/N);
##    X(k) = (reX(k) + 1i * imX(k));
##  endfor
##endfor
##endfunction
##function [re,im] = dft_try(in)
##  k = 0:(length(in)/2);
##  n = 0:(length(in)-1);
##  N = length(in);
##  c = cos(2*pi*k'*n/N);
##  s = sin(2*pi*k'*n/N);
##  re = in*c';
##  im = -in*s';
##endfunction
% function out = my_dft_for(in)
%   N = length(in);
%   for k = 1:(length(in)/2)
%     sum = 0;
%     for n = 0:(length(in)-1)
%       sum = sum + exp(-i*2*pi*(k-1)*n/N)*in(n+1);
%     endfor
%     out(k) = sum;
%   endfor
% endfunction
% function X = dtf_dft(x)
% N = length(x);
% reX = zeros(1, N/2 + 1);
% imX = zeros(1, N/2 + 1);
% X = zeros(1, N);
% for k = 1:N/2
%   for n = 1:N
%     reX(k) = reX(k) + x(n)*cos(2*pi*(k-1)*(n-1)/N);
%     imX(k) = imX(k) -x(n)*sin(2*pi*(k-1)*(n-1)/N);
%     X(k) = (reX(k) + 1i * imX(k));
%   endfor
% endfor
% endfunction