function y = delta(x)
  y = (x==0);
end
function y = unit_step(x)
  y(x>0) = 1;
end
%n1 = 0:25;
%n2 = -15:25;
%n3 = -10:10;
%n4 = 0:50;
%w = [pi/15 3*pi pi/sqrt(23)];
%subplot(411);
%plot(n1,sin(w(1)*n1));
%stem(n1,sin(w(1)*n1));
%subplot(412);
%plot(n2,sin(w(2)*n2));
%stem(n2,sin(w(2)*n2));
%subplot(413);
%plot(n3,sin(w(2)*n3));
%stem(n3,cos(w(2)*n3));
%subplot(414);
%plot(n4,sin(w(3)*n4));
%stem(n4,sin(w(3)*n4));

a = -10:2:10;
k = size(a);
b = 1:2:k(2);
%f = (a.^b).*((a)^(-1));

a = [1.7 1.2 1.3 4.8];
b = [9 0 333 8];

fd1=figure;
figure(fd1);

x = 1:20;
y = a(1)*delta(x-b(1));
subplot(411);
stem(x,y)

x = -15:15;
y = a(2)*delta(x-b(2));
subplot(412);
stem(x,y)

x = 300:350;
y = a(3)*unit_step(x-b(3));
subplot(413);
stem(x,y);

x = -10:0;
y = a(4)*unit_step(x+b(4));
subplot(414);
stem(x,y);

fsin = figure;
figure(fsin);
subplot(211);
f = 1500;
phi = 30*pi/180;
A = 65;
fs = 10000;
t = 0:1/fs:6/1000;
sin_signal = A*sin(2*pi*f*t+phi);
plot(t,sin_signal);
subplot(212);
stem(t, sin_signal);

expf = figure;
figure(expf);

a = 0.95;
n = 1:40;
exp_signal = (a.^n).*unit_step(n);
subplot(211);
plot(n, exp_signal);
subplot(212);
stem(n, exp_signal);

com_expf = figure;
figure(com_expf);

r = 0.99;
O = [45*pi/180 30*pi/180 10*pi/180];
n = 1:100;

com_exp = (r.^n).*(cos(O(1)*n)+1j*sin(O(1)*n));
subplot(311);
plot(real(com_exp),imag(com_exp));

com_exp = (r.^n).*(cos(O(2)*n)+1j*sin(O(2)*n));
subplot(312);
plot(real(com_exp),imag(com_exp));

com_exp = (r.^n).*(cos(O(3)*n)+1j*sin(O(3)*n));
subplot(313);
plot(real(com_exp),imag(com_exp));

ei_funf = figure;
figure(ei_funf);

w = [pi/13 pi/3];
a = 1.05;
b = 0.99;


subplot(411);
n = 0:25;
ei_sin = (1/(1j*2))*(exp(1j*w(1)*n)-exp(-1j*w(1)*n));
plot(n, ei_sin);

subplot(412);
n = -15:25;
ei_cos = (1/2)*(exp(1j*w(2)*n)+exp(-1j*w(2)*n));
plot(n, ei_cos);

subplot(413);
n = -20:0;
ei_sin = (1/(1j*2))*(exp(1j*w(2)*n)-exp(-1j*w(2)*n));
f = (a.^n).*ei_sin;
plot(n, f);

subplot(414);
n = 0:50;
ei_cos = (1/2)*(exp(1j*w(2)*n)+exp(-1j*w(2)*n));
f = (b.^n).*ei_cos;
plot(n, f);





